# Multiverse Movie App Theme
ဒါကတော wordpress theme တစ်ခုဖြစ်ပါတယ်

## installation
install လုပ်ပြီး လုပ်ဆောင်ရမည့်အရာများ

### create `package` page
package ဆို့တဲ့ slug နဲ့ page Blank Page တစ်ခု create လုပ်ပါ။ သူက 'domain.com/package' ဆိုတဲ route ကို အလုပ်လုပ်ဖို့ပါ။ အဲဒီနေရာမှာ Packages တွေကို ပြမှာပါ


## using
### create package
package တွေကို ပုံမှန် post တင်တဲ့ အတိုင်းတင်ရမှာပါ အဲ့ဒီမှာ 'Duration' နဲ့ 'price' ဆိုတဲ့ field ပါပါလိမ့်မေ အဲ့ မှာ  'Duration' နဲ့ 'price' ကို ထည့်လိုက်ပါ
### create Download link
Movie Apps တွေကို OS အစုံနဲ့ Dowm နိုင်ဖို့ အတွက် Download link တွေ ထည့်ပေးရမှာပါ။ installation ပြီးတဲ့ အခါ Admin Left panel မှာ Apps ဆို တဲ့ menu ပါလာပါလိမ့်မေ အဲဒီမှာ လိုသလို စိတ်ကြိုတ် ပြင်ဆင်ပေါင်းထည့်နိုင်ပါတယ်