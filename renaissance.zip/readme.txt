https://wphierarchy.com for wp structure
see https://youtu.be/-h7gOJbIpmo for tutorial